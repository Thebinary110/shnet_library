"""
A loss functions measures how goof our predictions are,
we can use this to adjust the parameters of our network
"""
from xml.etree.ElementPath import prepare_descendant

import numpy as np
from shnet.tensor import Tensor


class Loss:
    def loss(self, predicted:Tensor, actual:Tensor) -> float:
        raise NotImplementedError

    def grad(self, predicted:Tensor, actual:Tensor) ->  float:
        raise NotImplementedError


"""
MSE is mean squared error but we are going to use the total aquared error
"""

class MSE(Loss):
    def loss(self, predicted:Tensor, actual:Tensor) -> float:
        return np.mean((predicted - actual) ** 2)

    def grad(self, predicted: Tensor, actual: Tensor) ->  Tensor:
        return 2 * (predicted - actual) / predicted.size


class CrossEntropy(Loss):
    def loss(self, predicted, actual):
        exp = np.exp(predicted - np.max(predicted, axis=1, keepdims=True))
        probs = exp / np.sum(exp, axis=1, keepdims=True)

        eps = 1e-9
        probs = np.clip(probs, eps, 1 - eps)

        return -np.sum(actual * np.log(probs))

    def grad(self, predicted, actual):
        exp = np.exp(predicted - np.max(predicted, axis=1, keepdims=True))
        probs = exp / np.sum(exp, axis=1, keepdims=True)
        return probs - actual

